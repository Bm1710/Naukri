package com.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SalaryPredictor_page {

	static WebDriver driver;
	public void launchChrome()
	{
		System.setProperty("webdriver.chrome.driver","C:\\844924\\Naukri\\Drivers\\chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void url()
	{
		driver.get("https://www.naukri.com/");
		String windowTitle= getCurrentWindowTitle();
		String mainWindow = getMainWindowHandle(driver);
		Assert.assertTrue(closeAllOtherWindows(mainWindow));
		Assert.assertTrue(windowTitle.contains("Jobs - Recruitment"));
	}
		
	public String getMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	public String getCurrentWindowTitle() {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}
	
	//To close all the other windows except the main window.
	public static boolean closeAllOtherWindows(String openWindowHandle) {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(openWindowHandle)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}
		}
		
		driver.switchTo().window(openWindowHandle);
		if (driver.getWindowHandles().size() == 1)
			return true;
		else
			return false;
	}
	public void loginn() throws IOException
	{
		driver.findElement(By.xpath("//*[@id=\"login_Layer\"]/div")).click();
		
		
		driver.findElement(By.id("eLoginNew")).sendKeys("suryatejayalla96@gmail.com");
		driver.findElement(By.id("pLogin")).sendKeys("bmseven@7");
		driver.findElement(By.xpath("//*[@id=\"lgnFrmNew\"]/div[9]/button")).click();
	}
	public void mouseover(String xpath1,String xpath2)
	{

		WebElement a1 = driver.findElement(By.xpath(xpath1));
		WebElement a2 = driver.findElement(By.xpath(xpath2));
		Actions act = new Actions(driver);
		act.moveToElement(a1);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		act.moveToElement(a2).click().build().perform();
	}
	public void details()
	{
		driver.findElement(By.xpath("//*[@id=\"f0\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"farea_67\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"r12\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"role_7\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"i0\"]")).click();
		
		
		
		driver.findElement(By.xpath("//*[@id=\"ind_25\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"i1\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"loc_17\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"i2\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"gender_M\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"totalExperience\"]")).sendKeys("3 years");
		
		
		driver.findElement(By.xpath("//*[@id=\"companySugg\"]")).sendKeys("Abc Solutions");
		
		driver.findElement(By.xpath("//*[@id=\"designationSugg\"]")).sendKeys("Test Engineer");
		
		
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[3]/div[3]/div[1]/select[1]")).click();
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[3]/div[3]/div[1]/select[1]/option[4]")).click();
		
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[3]/div[3]/div[1]/select[2]")).click();

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[3]/div[3]/div[1]/select[2]/option[2]")).click();
	
		
		
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[4]/div[2]/select")).click();
		

		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[4]/div[2]/select/option[1]")).click();

		driver.findElement(By.xpath("//*[@id=\"e0\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"ugc_12\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"u32\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"ugc_12__ugs_16\"]")).click();

		driver.findElement(By.xpath("//*[@id=\"s0\"]")).click();
		
		
		driver.findElement(By.xpath("//*[@id=\"yopField_2019\"]")).click();
		
		driver.findElement(By.xpath("//*[@id=\"instituteSugg\"]")).sendKeys("Andhra University");
		
		driver.findElement(By.xpath("//*[@id=\"sugDrp_instituteSugg\"]/ul/li[1]/div")).click();
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[4]/div[8]/button")).click();
	
	}
	
	
	
	
	
	
}
