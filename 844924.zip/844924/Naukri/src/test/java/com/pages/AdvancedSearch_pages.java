package com.pages;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class AdvancedSearch_pages {
	static WebDriver driver;

	
	public void launchChrome()
	{
		System.setProperty("webdriver.chrome.driver","C:\\844924\\Naukri\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	public void url()
	{
		driver.get("https://www.naukri.com/");
		String windowTitle= getCurrentWindowTitle();
		String mainWindow = getMainWindowHandle(driver);
		Assert.assertTrue(closeAllOtherWindows(mainWindow));
		Assert.assertTrue(windowTitle.contains("Jobs - Recruitment"));
	}
		
	public String getMainWindowHandle(WebDriver driver) {
		return driver.getWindowHandle();
	}

	public String getCurrentWindowTitle() {
		String windowTitle = driver.getTitle();
		return windowTitle;
	}
	
	//To close all the other windows except the main window.
	public static boolean closeAllOtherWindows(String openWindowHandle) {
		Set<String> allWindowHandles = driver.getWindowHandles();
		for (String currentWindowHandle : allWindowHandles) {
			if (!currentWindowHandle.equals(openWindowHandle)) {
				driver.switchTo().window(currentWindowHandle);
				driver.close();
			}
		}
		
		driver.switchTo().window(openWindowHandle);
		if (driver.getWindowHandles().size() == 1)
			return true;
		else
			return false;
	}
	
	public void login_search() throws IOException
	{   
        driver.findElement(By.xpath("//*[@id=\"login_Layer\"]/div")).click();
		driver.findElement(By.id("eLoginNew")).sendKeys("tejaswini.m481@gmail.com");
		driver.findElement(By.id("pLogin")).sendKeys("tejaswini@24");
		driver.findElement(By.xpath("//*[@id=\"lgnFrmNew\"]/div[9]/button")).click();
	}
	
	public void search_job() throws InterruptedException {
		driver.findElement(By.xpath("//*[@id=\"qsb-keyskill-sugg\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"search-jobs\"]/a")).click();
		
	    driver.findElement(By.xpath("//*[@id=\"advKeyskills\"]/div[1]/div[2]/input")).sendKeys("cognizant");
	    driver.findElement(By.xpath("//*[@id=\"Sug_advLocation\"]")).sendKeys("chennai");
		driver.findElement(By.xpath("//*[@id=\"adv_workExp_year\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_expyr6\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"adv_workExp_month\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_expmn2\"]")).click();   
		driver.findElement(By.xpath("//*[@id=\"adv_exp_min\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"dd_cja_min8\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"ddAdvIndusrty\"]/div[1]/ul/li/div/input")).click();
	    driver.findElement(By.xpath("//*[@id=\"ul_ddAdvIndusrty\"]/div/div[1]/ul/li[22]/a")).click();

	    
	    driver.findElement(By.xpath("//*[@id=\"adv_jobCategory\"]")).click();
	    driver.findElement(By.xpath("//*[@id=\"24\"]")).click();
	    
	    driver.findElement(By.xpath("//*[@id=\"advFrm\"]/div[7]/div[2]/div/div[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id=\"advFrm\"]/div[8]/div[2]/div/div[1]/a")).click();
	    driver.findElement(By.xpath("//*[@id=\"adv_submit\"]")).click();
	    
	    
	    
	    
	    
	
		Thread.sleep(5000);
		driver.close();
		
	}

}
