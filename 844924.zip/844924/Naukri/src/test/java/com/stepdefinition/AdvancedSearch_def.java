package com.stepdefinition;

import java.io.IOException;

import com.pages.AdvancedSearch_pages;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdvancedSearch_def {
AdvancedSearch_pages ss=new AdvancedSearch_pages();
	
	@Given("^user launched the chrome browser for search scenario$")
	public void user_launched_the_chrome_browser_for_search_scenario()  {
		ss.launchChrome();
	    ss.url();
	}

	@When("^user opens naukri homepage for search scenario$")
	public void user_opens_naukri_homepage_for_search_scenario() throws IOException  {
	   ss.login_search();
	}
	@Then("^when user clicks search$")
	public void when_user_clicks_search() throws InterruptedException  {
		ss.search_job();
	}
}
