package com.stepdefinition;

import java.io.IOException;

import com.pages.Field_page;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Field_def extends Field_page {
	
	@Given("^user can launched the chrome browser$")
	public void user_can_launched_the_chrome_browser()  {
		 launchChrome();
	}

	@When("^user opens the naukri homepage$")
	public void user_opens_the_naukri_homepage()  {
		url();
	}



    @When("^user login to naukri homepage$")
    public void user_login_to_naukri_homepage() throws IOException{
    	loginn() ;
    }




	@Then("^the user can go to recruiters option$")
	public void the_user_can_go_to_recruiters_option() throws IOException  {
		loginn() ;
	}

	@When("^the user click on browse all recruiters in the dropdown$")
	public void the_user_click_on_browse_all_recruiters_in_the_dropdown() throws InterruptedException  {
		 field();
	}

	


}
